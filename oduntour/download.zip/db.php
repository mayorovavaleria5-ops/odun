<?php
$host = 'sql204.infinityfree.com';
$user = 'if0_43386491';
$pass = 'XsXYFcFBHyjhee1';
$dbname = 'if0_43386491_oduntour';

// Подключаемся к базе данных напрямую
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения к серверу: " . $conn->connect_error);
}

// Устанавливаем кодировку
$conn->set_charset("utf8mb4");
?>